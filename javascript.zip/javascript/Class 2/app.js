var x, y, z
x = 5;
y = 6;
z = x + y
