## The javascript syntax defines two types of values
* Fixed Values -  They are called literals
* Variable Values - They are only called variables
## JavaScript Literals
The two most important syntax rules for fixed values are:
* **Numbers** are written with or without decimals

```
10.50
1001

document.getElementById("demo").innerHTML = 10.50;

// The 10.50 is the fixed value
```
* **Strings** are text, writen within double or single quotes.

```
"John Doe"
'John Doe'

document.getElementById("demo").innerHTML = 'John Doe';
// The 'John Doe' is the fixed value
```


## JavaScript Variables
variables are used to store values

In JS, uses the `var` keyword to **declare** variables

An equal sign is used to **assign values** to variabes.

```
var x, y, z
x = 5;
y = 6;
z = x + y;
```

## JavaScript Operators
Js uses **arithmetic operators** (/ + - *) to **compute** values

```
document.getElementById("demo").innerHTML = (5 + 6) * 10;

assingment operator **=** is used to assign values to variables
```

## JavaScript Expressions
an expression is a combination of values, variables, and operators, which computes to a value.
```
For ex (5 * 10) evaluates to 50

x * 10
// x is variables 

"John" + " " + "Doe"
```

## JavaScript Comments
Code after double slashes `//` or between `/*` and `*/` is treated as a comment.

## Javascript Identifiers
* Identifiers are names
* In JS identifiers are used to name variables (and keywords, and functions and labels)
* In Js the first char must be a letter, or an underscore (_), or a dollar sign ($)

## JavaScript is case Sensitive
all JS identifiers are case sensitive
The variables lastName and lastname, are different variables.

