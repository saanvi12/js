## the javascript syntax defines two types of values
* fixed values (called literals)
* variable values (only called variables)
## javascript literals
the two most important syntax rules for fixed values are:
* **Numbers** are written with or without decimals

```
10.50
1001
```
* **strings** are text, written within double or single quotes.

```
"john doe"
'john doe'
```
## javascript variables
variables are used to store values

in JS, uses the `var` keyword to declare variables
An equal sign is used to **assign values** to variables.

```
var x, y, z
x = 5;
y = 6;
z = 5 + 6;
```

## javascript operators
JS uses **arithmetic operators** (/ - + *) to **compute** values

```
document.getElementById("demo").innerHTML = (5+6) * 10;

assignment operator **-** is used to assign values to variables
```

## javascript expressions 
an expression is a combination of values, variables, and operators, which computes to a value.

```
for example, (5*10) evaluates to 50

x * 10
// x is variables

"john" + " " + "doe"
```

## javascript comments
code after double slashes `//` or between `/*` and `*/` is treated as a comment

## javascript identifiers
identifiers are names

in JS indentifiers are used to name variables (and keywords, functions, and labels)

in JS the first character must be a letter, or an underscore ('_'), or a dollar sign ('$')

## javascript is case sensitive
all JS identifiers are case sensitive
the variables lastname and lastName are different variables.