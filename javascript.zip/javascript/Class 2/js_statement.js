function statements() {
    var x, y, z;
    x = 5;
    y = 6;
    z = x + y;
    //side note: Java is an Object Oriented programming language, and JavaScript is an Object Oriented scripting language.
    //we can do multiple statements in the same line
    //a = 5; b = 6; c = a + b;
    document.getElementById("statn").innerHTML = "the value of z is" + z + ".";

}