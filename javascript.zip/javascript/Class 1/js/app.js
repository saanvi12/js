function func() {
    document.getElementById('test').innerHTML = "Add external JS yo"
}