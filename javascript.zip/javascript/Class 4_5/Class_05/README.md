## Arithmetic Operator
| Operator | Description                  |
| :------- | :--------------------------- |
| +        | Addition                     |
| -        | Subtraction                  |
| *        | Multiplication               |
| **       | Exponentiation               |
| /        | Division                     |
| %        | Modulus (Division Remainder) |
| ++       | Increment                    |
| --       | Decrement                    |


## Assignment Operator
| Operator | Example | Same As    |
| :------- | :------ | :--------- |
| =        | x = y   | x = y      |
| +=       | x += y  | x = x - y  |
| -=       | x -= y  | x = x + y  |
| *=       | x *= y  | x = x * y  |
| /=       | x /= y  | x = x /y   |
| %=       | x %= y  | x = x % y  |
| **=      | x **= y | x = x ** y |

## Comparison Operator

| Operator | Description                        |
| :------- | :--------------------------------- |
| ==       | Equal to                           |
| ===      | Equal value and equal type         |
| !=       | Not Equal                          |
| !==      | Not Equal value and Not equal type |
| >        | Greater than                       |
| <        | Less then                          |
| >=       | Greater then or equal to           |
| <=       | Less than or equal to              |
| ?        | Ternary Operator                   |

## Logical Operator

| Operator | Description |
| :------- | :---------- |
| &&       | Logical And |
|          |             |  | Logical Or |
| !        | Logical Not |


## Type Operator

| Operator   | Description                                               |
| :--------- | :-------------------------------------------------------- |
| typeof     | Returns the type of a variable                            |
| instanceof | Returs true if an object is an instance of an object type |


# Javascript Functions
A JS function is defined with the `function` keyword, followed by a **name**, followed by parenthese **()**.
Function names can contain letters, digits, unssersscores, and dollar signs (same as variables).

The parenthese may include parameter names seperated by commas:
**(parameter1, paramter2, ...)**

Example of a .js function 
```
function doStuff(x, y) {
    return x * y;
}
```